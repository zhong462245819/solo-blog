title: mybatis核心映射
date: '2019-09-01 22:45:37'
updated: '2019-09-01 22:45:37'
tags: [Note]
permalink: /articles/2019/09/01/1567349137928.html
---
* Mybatis输入映射（掌握）
    * 通过parameterType指定输入参数的类型，类型可以是简单类型、hashmap、pojo的包装类型 
        * 传递pojo的包装对象 
            * 需求：完成用户信息的综合查询，需要传入查询条件很复杂（可能包括用户信息、其它信息，比如商品、订单的）
            * 针对上边需求，建议使用自定义的包装类型的pojo。 在包装类型的pojo中将复杂的查询条件包装进去。
* Mybatis输出映射（掌握）
1. resultType 
    * 使用resultType进行输出映射，只有查询出来的列名和pojo中的属性名一致，该列才可以映射成功。
    * 如果查询出来的列名和pojo中的属性名全部不一致，没有创建pojo对象。
    * 只要查询出来的列名和pojo中的属性有一个一致，就会创建pojo对象
        1.  resultType的输出简单类型 
            * **需求**：用户信息的综合查询列表总数，通过查询总数和上边用户综合查询列表才可以实现分页。
        2. resultType的输出pojo对象和pojo列表
            * 不管是输出的pojo单个对象还是一个列表（list中包括pojo），在mapper.xml中resultType指定的类型是一样的。 
                * 在mapper.java指定的方法返回值类型不一样：
                    1. 输出pojo对象list，方法返回值是List<简单java对象> 
                    2. 输出单个pojo对象，方法返回值是单个对象类型
2. resultMap
    * mybatis中使用resultMap完成高级输出结果映射。
* 总结:
    * **使用resultType进行输出映射，只有查询出来的列名和pojo中的属性名一致，该列才可以映射成功。**
    * **如果查询出来的列名和pojo的属性名不一致，通过定义一个resultMap对列名和pojo属性名之间作一个映射关系**