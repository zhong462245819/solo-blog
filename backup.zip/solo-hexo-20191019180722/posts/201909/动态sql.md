title: 动态sql
date: '2019-09-01 22:45:25'
updated: '2019-09-01 22:45:25'
tags: [Note]
permalink: /articles/2019/09/01/1567349125786.html
---
* 什么是动态sql
    * mybatis核心 对sql语句进行灵活操作，通过表达式进行判断，对sql进行灵活拼接、组装。
* **sql片段**
    * 将上边实现的动态sql判断代码块抽取出来，组成一个sql片段。其它的statement中就可以引用sql片段。方便程序员进行开发
        * 先定义一个sql片段
        * 使用include标签引用，设置refid属性
        ```
         <where>
            <!--引用sql的id，如果refid引用的sql的id不在本mapper中，则需要家其他mapper的namespace-->
            <include refid="Query_user"/>
        </where>
        ```
* **foreach** 
    * 向sql传递数组或List，mybatis使用foreach解析
    * 在用户查询列表和查询总数的statement中增加多个id输入查询。即实现SELECT * FROM USER WHERE id=1 OR id=10 OR id=16