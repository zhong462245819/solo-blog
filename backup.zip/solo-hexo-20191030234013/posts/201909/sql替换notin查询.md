title: sql替换not in查询
date: '2019-09-03 23:11:51'
updated: '2019-09-03 23:11:51'
tags: [mysql]
permalink: /articles/2019/09/03/1567523511515.html
---
1. 通过外链接，使用isnull
	```
	SELECT
		* 
	FROM
		ums_user AS t1
		LEFT JOIN ( SELECT user_id FROM ums_role_user_relation WHERE role_id = 2 ) AS t2 ON t1.id = t2.user_id 
	WHERE
		t1.deleted = 0 
		AND t1.enabled = 1 
		AND t2.user_id IS NULL
	```
2. 使用not exists