title: jdk的下载安装与环境变量的配置
date: '2019-09-01 22:45:31'
updated: '2019-09-01 22:45:31'
tags: [Note]
permalink: /articles/2019/09/01/1567349131337.html
---
### 下载JDK

#### Java已经被Oracle收购，进入Oracle官网下载

[Oracle](https://www.oracle.com/index.html)

#### 下载步骤

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/E68B8D60328540C6998D03C2143B300A/35629)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/D00F105EA0ED4C9886FBE28037D646DE/35631)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/9629046A7DF64B25BE446237CF889BA4/35633)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/D93A1B4F170446379ABD054327467EC1/35635)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/664826504E3C4AE7A133B22192C8C55E/35656)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/4A43EB4E846E472E9D574DC0808D0B33/35643)

---

## 下载安装之后

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/807AF0D0792F4F4C8C591318043A1459/35661)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/4046A67D40614B92A33EDEEBD94F19BE/35663)

---

#### 配置环境变量

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/9F5C55EAD24646EDB7A469CEC2F7F0AE/35670)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/50342BF241B84355A993DC0272B29252/35672)

---

## 测试环境变量是否配置成功

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/2EE3178339F74AF3BAFBAAF0D62E7FDF/35680)

![image](https://note.youdao.com/yws/public/resource/e341e3a035926639e0e368f838282a8f/xmlnote/8A45D42511964912B4E14F9AD0F105B5/35682)