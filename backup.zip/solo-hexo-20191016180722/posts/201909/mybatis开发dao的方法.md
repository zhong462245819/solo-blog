title: mybatis开发dao的方法
date: '2019-09-01 22:45:35'
updated: '2019-09-01 22:45:35'
tags: [Note]
permalink: /articles/2019/09/01/1567349135466.html
---
#### Mybatis开发dao的方法
* 原始dao开发方法(程序员需要编写dao和dao实现类)
1. 新建包Dao
    1. 创建BassDao公共dao类(创建getSQLSession方法)
        ```
        public SqlSession getSqlSession(){
        //配置资源文件
        String resource = "mybatis-config.xml";
        //初始化文件读取对象，读取mybatis-config.xml文件里面的内容
        Reader reader = null;
        try {
            reader = Resources.getResourceAsReader(resource);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(sqlSessionFactory==null) {
            //根据reader中的内容创建sql会话工厂.
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
        }
        SqlSession sqlSession  = sqlSessionFactory.openSession();
        return  sqlSession;
        }
        ```
* Mybatis 的mapper接口(相当于dao接口)代理开发方法(需要在SqlMapConfig.xml中加载mapper.xml这个映射文件 )
* 总结
    *  原始dao开发问题 
        * dao接口实现类方法中存在大量模板方法，设想能否将这些代码提取出来，大大减轻程序员的工作量。
        * 调用sqlsession方法时将statement的id硬编码了
    * mapper开发
        * 只需要编写两个文件，mapper.java,mapper.xml。即可，不需要类来继承它。
        * mapper开发只需要遵守几个规范即可
            * 在mapper.xml中namespace等于mapper接口地址
            * mapper.java接口中的方法名和mapper.xml中statement的id一致 
            * mapper.java接口中的方法输入参数类型和mapper.xml中statement的parameterType指定的类型一致。 
            * mapper.java接口中的方法返回值类型和mapper.xml中statement的resultType指定的类型一致。
            * 其实，以上开发规范主要是对下边的代码进行统一生成：
                
                ```
                User user = sqlSession.selectOne("test.findUserById", id);
                sqlSession.insert("test.insertUser", user);
                。。。。
                ```
            * mapper接口方法参数只能有一个是否影响系统 开发？mapper接口方法参数只能有一个，系统是否不利于扩展维护？
            
                * 系统框架中，dao层的代码是被业务层公用的。
                
                * 即使mapper接口只有一个参数，可以使用包装类型的pojo满足不同的业务方法的需求。

                    **注意：持久层方法的参数可以包装类型、map。。。，service方法中建议不要使用包装类型（不利于业务层的可扩展）。**