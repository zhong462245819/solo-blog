title: 04 - java之旅
date: '2019-09-01 22:45:24'
updated: '2019-09-01 22:45:24'
tags: [Note]
permalink: /articles/2019/09/01/1567349124687.html
---
### Java简介

#### Java的历史:

> ​	Java之父——**詹姆斯·高斯林**
>
> ![1531062091742](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/DBFFE6FF502046F09E07354DCAE808F0/28546)
>

![image](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/07B33836ABC345698552A53E4D27D30B/35770)

> ​	java(前世[Oak](https://note.youdao.com/yws/public/resource/da4cd0b579d44606c302fc0354a955fd/xmlnote/08D75C621B854BF5ABC26A471E415687/28062)是sun(Stanford Univesity Network)公司开发的一门编程语言1995年5月23日java 1.0版本正式在SunWorld大会上发布,2009年被oracle(甲骨文)收购，其实编程语言就是用来编写软件的。

|    版本    | 描述                                                         |
| :--------: | :----------------------------------------------------------- |
| 1991年1月  | Sun公司成立了Green项目小组，专攻智能家电的嵌入式控制系统     |
| 1991年2月  | 放弃C++，开发新语言，命名为“Oak”                             |
| 1991年6月  | JamesGosling开发了Oak的解释器                                |
| 1992年1月  | Green完成了Green操作系统、Oak语言、类库等开发                |
| 1992年11月 | Green计划转化成“FirstPerson”，一个Sun公司的全资母公司        |
| 1993年2月  | 获得时代华纳的电视机顶盒交互系统的订单，于是开发的重心从家庭消费电子产品转到了电视盒机顶盒的相关平台上。 |
| 1994年6月  | FirstPerson公司倒闭，员工都合并到Sun公司。Liveoak计划启动了，目标是使用Oak语言设计出一个操作系统。 |
| 1994年7月  | 第一个Java语言的Web浏览器WebRunner（后来改名为HotJava），Oak更名为Java。 |
| 1994年10月 | VanHoff编写的Java编译器用于Java语言                          |
| 1995年3月  | 在SunWorld大会，Sun公司正式介绍了Java和HotJava。             |
| 1996年1月  | JDK1.0发布                                                   |
| 1997年2月  | J2SE1.1发布                                                  |
| 1998年12月 | J2SE1.2发布                                                  |
| 1999年6月  | 发布Java的三个版本：J2SE、J2EE、J2ME                         |
| 2000年5月  | J2SE1.3发布                                                  |
| 2001年9月  | J2EE1.3发布                                                  |
| 2002年2月  | J2SE1.4发布                                                  |
| 2004年9月  | J2SE1.5发布，将J2SE1.5改名JavaSE5.0                          |
| 2005年6月  | JavaSE6.0发布，J2EE更名为JavaEE，J2SE更名为JavaSE，J2ME更名为JavaME |
| 2006年12月 | JRE6.0发布                                                   |
| 2006年12月 | JavaSE6发布                                                  |
| 2009年12月 | JavaEE6发布                                                  |
| 2009年4月  | Oracle收购Sun                                                |
| 2011年7月  | JavaSE7发布                                                  |
| 2014年3月  | JavaSE8发布                                                  |

就在去年千呼万唤始出来-java9.0在9月21号发布········

#### Java的三大版本

>* **JavaSE**(Java Platform Standard Edition) Java平台标准版
>
>* **JavaME**(Java Platform Micro Edition) Java平台微版-用于嵌入式开发(机顶盒、打印机)
>
>* **JavaEE**(Java Platform Enterprise Edition) Java企业版-用于企业开发

#### Java的特性

> ​	**前方高能、简单**
>
> ​	**跨平台性(Write Once,Run AnyWhere)**
>
> ​		平台指的是操作系统 （Windows，Linux，Mac）
>
>  		Java程序可以在任意操作系统上运行，一次编写到处运行()
>
> ​		实现跨平台需要依赖Java的虚拟机 JVM （Java Virtual Machine）
>
> ​	**面向对象**
>
> ​	**安全性**——(无指针、自动释放内存、数组边界检查 、强制类型转换检验等)

> ​ **健壮性**

> ​ **可移植性**



#### 运行一个Java程序需要什么因素

>* JDK(Java Development Kit) -java开发工具包，它的组成包括:
>
>* **javac** ——编译器，将java源文件转换为 .class 结尾的二进制字节码文件
>
>* jar —— 打包工具，将相关的类文件打包成一个文件
>
>* javadoc —— 文档生成器，从源码注释中提取文档
>
>* jdb-debugger —— 差错工具
>
>* appletviewer —— 一种执行HTML文件上的Java小程序的Java浏览器。
>
>* **java** —— 运行编译后的java程序(运行 .class 结尾的文件)  
>
>* **JRE**（java runtime environment —— java运行环境
>
> ················
>
>一个java程序需要先编译后运行，运行时需要有运行环境的支撑

>* JVM(Java Virtual Machine)Java虚拟机

---

#### 安装JDK与配置环境变量

[安装JDK与配置环境变量](http://note.youdao.com/noteshare?id=86a132e178ca3d3942876e1af89f57c6&sub=E2AACE3FEEC54ACAABEF6728548FCEF4)


---

#### 创建人生中的第一个JAVA程序

> * 1.鼠标右键——新建——文本文档。取名为 HelloWorld.java 
>
> ​	注意： 文本文档是.txt结尾的，我们需要 .java结尾的文件
>
> ![1528470384453](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/8F5EC1DEF906405694D002C6F46EA506/28589)
>
> ​	如果没有后缀显示需要去设置
>
> * 2.打开HelloWorld.java输入
>
> ![1528470452761](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/99CA368979464150A606FA3AC439433A/28580)
>
> ```
> public class HelloWorld{
> 	public static void main(String[] args){
> 		System.out.println("HelloWorld！！！");
> 	}
> }
> ```

> * 3.编译这个HelloWorld.java文件
>
> ​		1.打开CMD 
>
> ​		2.输入 javac HelloWorld.java 
>
> ![1528470512411](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/DD78248CE5C44A95B75CC8E71620CCB6/28588)
>
> ​		编译之后会生成一个HelloWorld.class的二进制字节码文件
>
> ![1528470538083](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/8D78B32CC8424D1E95594E36880D6770/28587)
>
> ​		运行HelloWorld.class,在cmd里面输入 java HelloWorld（注意这里HelloWorld后面不要后缀）
>
> ​![1528470575715](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/F4B8A79E8D05452DB2B356C6D60E790A/28586)

![1528737458280](https://note.youdao.com/yws/public/resource/8d31358f7281014728a378b224159c7e/xmlnote/A8EC792034834B96911C8A0D37D60C0E/28584)