title: mybatisi多对多映射
date: '2019-09-01 22:45:26'
updated: '2019-09-01 22:45:26'
tags: [Note]
permalink: /articles/2019/09/01/1567349126007.html
---
## 3.21
####  mybatisi多对多映射 ####
Resultmap节点的定义和使用(单向一对多映射)
列名和属性名不一致导致查询的结果某个字段为null
```
	<resultMap id="UserMapper" type="com.qf.pojo.User">
	    <id property="id" column="ID"/>
	    <result property="name" column="Name"/>
	    <result property="age" column="Age"/>
	    <collection property="roleList" ofType="com.qf.pojo.Role">
	        <id column="rid" property="rid"></id>
	        <result property="rname" column="rname"></result>
	    </collection>
	</resultMap>
```
a)	在User类中新增集合属性List<Role> roleList，并添加getter、setter方法，重写toString方法
b)	在UserMapper.xml中添加查询节点如下
```
    <select id="findAll" resultMap="UserMapper">
		SELECT * from user u inner join user_role ur on u.id = ur.uid
		inner join role r on ur.rid = r.rid
	</select>
```		
c)	添加测试代码，调用findAll查询

d)	如果需要通过角色查询，请新建RoleMapper.xml，重复类似操作即可，双向一对多即为多对多。

####  Mybatis关联映射之一对一 ####
a)	假设现有订单(Order)、客户(Customer)二表，关系为单向一对多，客户为一，订单为多。
b)	新建数据库表Order(包含客户外键customerId)，Customer(包含主键cId)
c)	新建实体类Order如下
```
  Public class Order{
    Private 属性1;
    Private 属性2;
    Private 属性3;
    ……
    Private Customer customer;
    Getter&Setter……
    } 
```
d)	创建映射文件OrderMapper.xml,如下所示
```
<resultMap id="OrderMapper" type="com.qf.pojo.Order">
    <id property="id" column="ID"/>
    <result property="name" column="Name"/>
    <result property="path" column="Path"/>
<!--注意，javaType是指一对一的属性类型，而ofType是指映射到List中的pojo类型，所以一对一用javaType，一对多用ofType-->
    <association property="customer" javaType="com.qf.pojo.Customer">
        <id column="cid" property="cid"></id>
        <result property="cname" column="cname"></result>
    </ association >
</resultMap>
```
e)	记得把你声明的Mapper.xml映射到Mybatis-config.xml中
f)	使用连接查询查出数据，并把resultMap设置为上面声明的OrderMapper,如下所示

```
<select id="findAllOrders" resultMap=" OrderMapper ">
    SELECT * from Order o left join Customer c on o.customerId = c.cid 
</select>
```
g)	测试
####  Mybatis注解
https://www.cnblogs.com/lxnlxn/p/5996707.html