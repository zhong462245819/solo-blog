title: 05b - intellij idea的使用
date: '2019-09-01 22:45:31'
updated: '2019-09-01 22:45:31'
tags: [Note]
permalink: /articles/2019/09/01/1567349131769.html
---
## 下载

#### 进入官网
[点击进入官网](http://www.jetbrains.com/)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/D1C7B57409C94BD1B17DE9777F2DD0CA/35505)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/BCD7418005EC4938991CFFD8DB8BF4ED/35507)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/D315E9DB0A6043BDB614767AA7F0FC5E/35509)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/8125959D0EA741FF98C24FFDA9D7386B/35522)

---

### 安装

##### 1.双击打开

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/480140238A6E4AFF95A5B47B55793E89/35526)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/D22B2D7E34684033BC5907669BAA51B6/35528)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/E92A05C878674A4A8C5538AC477C94AD/35530)

## 修改hosts文件与获取注册码

##### 修改hosts

[点击获取注册码](http://idea.lanyus.com/)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/5827253335A64C00A5C171F73049C00F/35544)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/51BD44E21E5944D182EC41151EFB3D5A/35546)

##### 获取注册码

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/D6EBABFE2D4D413C8AC3DCC3C844624C/35542)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/30EC6864B31448629D3EE3C5D21A70E8/35556)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/965CB2603B7F4B5AA11D8639E33FBF79/35560)

---

#### IDEA的使用

##### 创建Java项目

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/290119380ED248778996C713B805826F/35570)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/8766359D436E4115A70E4F11C10E4E69/35572)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/238BE9C963E54FAAB28085B2847144FC/35574)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/7744FC2A892F4C8588B682CE668C8DE8/35576)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/732225E25EA34CC089FF89F0D4A07215/35578)

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/668B3B3D80154731AAB88CB667E980D7/35580)

#### 修改字符集编码

File -> Settings （全都改为UTF-8 国际码）

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/BEDC2AAB72F3427099CDAA9F274CFDC8/35591)

#### 修改代码字体与大小

![image](https://note.youdao.com/yws/public/resource/be52a0556998f7ead43e8e987d5d3631/xmlnote/7865CF1EEF514036A76C8ED3AA83A3F7/35598)


#### [还需要修改别的请找度娘](https://ww.baidu.com/)