title: 16 - List
date: '2019-09-01 22:45:33'
updated: '2019-09-01 22:45:33'
tags: [Note]
permalink: /articles/2019/09/01/1567349133327.html
---
## 集合介绍

> 集合，集合是java中提供的一种容器，可以用来存储多个数据

> 在前面的学习中，我们知道数据多了，可以使用数组存放,那么，集合和数组既然都是容器，它们有啥区别呢

* 数组的长度是固定的。集合的长度是可变的
* 集合中存储的元素必须是引用类型数据

## 集合结构图

![image](https://note.youdao.com/yws/public/resource/0d85edf8b551a7472c8ae2f8510993b8/xmlnote/F8B65D4606FC47099374FCFDC02846B7/30704)

---

### 为什么使用集合框架

![image](https://note.youdao.com/yws/public/resource/0d85edf8b551a7472c8ae2f8510993b8/xmlnote/38901D412161423B82A96F3F856501CF/30710)

---

## 集合Collection的方法

> Collection接口中的方法
*  是集合中所有实现类必须拥有的方法
*  使用Collection接口的实现类,程序的演示
*  ArrayList implements List
*  List extends Collection
*  方法的执行,都是实现的重写

> Conllection 集合中基本的方法

![image](https://note.youdao.com/yws/public/resource/0d85edf8b551a7472c8ae2f8510993b8/xmlnote/2A8FDEB7489E40899D0FD4FD059A304E/31057)

---

> **已知Collection 与 List 都是接口，而我们只能用多态的形式使用**

> **创建集合的格式**

> 方式1 ： **Collection<声明要存储元素的数据类型> 变量名 = new ArrayList<声明要存储元素的数据类型>();**

* 声明要存储元素的数据类型只能是**引用类型**

> 方式2 ： **Collection 变量名 = new ArrayList();** 存储的类型为Object

> 演示Collection接口中的方法

* **方式2演练**

```
    //创建集合
    Collection coll = new ArrayList();
     
    //1,往集合中添加对象元素。add(E e)方法，E代表创建集合时所指定的数据类型如<String>，那么，E就代表String类型；创建集合时若没有指定数据类型，那么，E就代表Object类型。
    coll.add("江");
    coll.add("湖");
    coll.add("见");		
    //把集合打印一下。
    System.out.println(coll); //打印结果为：[江, 湖, 见]
    System.out.println(coll.toString()); //打印结果为：[江, 湖, 见]
    
    //2,从集合中删除元素。remove(Object o)方法
    coll.remove("湖");		
    //删除后，集合元素为[江, 见]
    
    //3,判断集合中是否包含指定元素。contains(Object o)方法
    System.out.println(coll.contains("江"));
    //打印结果为true
    System.out.println(coll.contains("湖"));
    //打印结果为false
    	
    //4,获取集合元素个数。size()方法
    System.out.println(coll.size());
    //打印结果为2
    
    //5,返回包含集合中所有元素的数组。toArray()方法
     Object[] array = coll.toArray();
     System.out.println(Arrays.toString(array));
    //数组中的元素为{"江", "见"}
    
    //6,清除集合元素。remove()方法
    coll.clear();
    //清空后，集合元素为[]，代表没有元素
    
    //7.情况只是清空元素，集合照样存在继续添加值
    coll.add("缘");
    System.out.println(coll);
```

## 迭代器

### Iterator迭代器概述

> java中提供了很多个集合，它们在存储元素时，采用的存储方式不同。我们要取出这些集合中的元素，可通过一种通用的获取方式来完成

> Collection集合元素的通用获取方式：在取元素之前先要判断集合中有没有元素，如果有，就把这个元素取出来，继续在判断，如果还有就再取出出来。一直把集合中的所有元素全部取出。这种取出方式专业术语称为迭代

> 集合中把这种取元素的方式描述在Iterator接口中。Iterator接口的常用方法如下

![image](https://note.youdao.com/yws/public/resource/0d85edf8b551a7472c8ae2f8510993b8/xmlnote/6FEB14679FC84FA68DDF69E49EBBD7BE/31099)

* hasNext（）方法：用来判断集合中是否有下一个元素可以迭代。如果返回true,说明可以迭代
* next（）方法：用来返回迭代的下一个元素，并把指针向后移动一位

* **迭代集合图解**
    ![image](https://note.youdao.com/yws/public/resource/0d85edf8b551a7472c8ae2f8510993b8/xmlnote/52809A2C3D234E0B83B1C99532D76236/31104)

---

## Iterator迭代方式的代码体现

```
    Collection coll = new ArrayList<>();
    coll.add("abc1");
    coll.add("abc2");
    coll.add("abc3");
    coll.add("abc4");
    coll.add(5);
    //2.获取容器的迭代器对象。通过iterator方法。
    Iterator it = coll.iterator();
    
    //3,使用具体的迭代器对象获取集合中的元素。参阅迭代器的方法
    while(it.hasNext()){
    	System.out.println(it.next());
    }
    
    // it.next();
    
    /* 
    迭代器for循环的形式的使用
    for (Iterator it = coll.iterator(); it.hasNext();  ) {
    	System.out.println(it.next());
    }
    */

```

* 注意：在进行集合元素取出时，如果集合中已经没有元素了，还继续使用迭代器的next方法，将会发生java.util.NoSuchElementException没有集合元素的错误

---

### 集合元素向下转型

> 学习到这里，基本知道了Collection接口的简单使用。可是集合中可以存储任何对象，那么存放进去的数据都是还是原来类型吗？不是了，提升成了Object

* 在使用集合时，我们需要注意以下几点
    * 集合中存储其实都是对象的地址
    * 集合中可以存储基本数值吗？jdk1.5版本以后可以存储了。因为出现了基本类型包装类，它提供了自动装箱操作（基本类型对象），这样，集合中的元素就是基本数值的包装类对象
    * 存储时提升了Object。取出时要使用元素的特有内容，必须向下转型

```
    Collection coll = new ArrayList();
    coll.add("aa");
    coll.add("bb");
    coll.add("cc");
    Iterator it = coll.iterator();
    while (it.hasNext()) {
    	//由于元素被存放进集合后全部被提升为Object类型
    //当需要使用子类对象特有方法时，需要向下转型
    	String str = (String) it.next();
    	System.out.println(str);
    }
```

* 注意 : 如果集合中存放的是多个对象，这时进行向下转型会发生类型转换异常java.lang.ClassCastException

```
    Collection coll = new ArrayList();
    coll.add("aa");
    coll.add("bb");
    coll.add("cc");
    coll.add(5);
    Iterator it = coll.iterator();
    while (it.hasNext()) {
    	//由于元素被存放进集合后全部被提升为Object类型
    //当需要使用子类对象特有方法时，需要向下转型
    	String str = (String) it.next();
    	System.out.println(str);
    }
```

---

* **方式1演练**

```
    Collection<String> coll = new ArrayList<String>();
    // 此时集合里面只能存String类型的元素
    coll.add("aa");
    coll.add("bb");
    coll.add("cc");
    // coll.add(5); 会报错
    Iterator<String> it = coll.iterator();
    
    while (it.hasNext()) {
	String str =  it.next(); 
    //当使用Iterator<String>控制元素类型后，就不需要强转了。获取到的元素直接就是String类型
    	System.out.println(str);
    }

```

---

### 增强for循环

> 增强for循环是JDK1.5以后出来的一个高级for循环，专门用来遍历数组和集合的。它的内部原理其实是个Iterator迭代器，所以在遍历的过程中，不能对集合中的元素进行增删操作

> 格式

```
    for(元素的数据类型  变量 : Collection集合or数组){

            
    }
```

> 它用于遍历Collection和数组。通常只进行遍历元素，不要在遍历的过程中对集合元素进行增删操作

* 练习1遍历数组

```
    int[] arr = new int[]{11,22,33};
    for (int n : arr) {//变量n代表被遍历到的数组元素
    	System.out.println(n);
    }
```

* 遍历集合

```
    Collection<String> coll = new ArrayList<String>();
    coll.add("aa");
    coll.add("bb");
    coll.add("cc");
    coll.add("dd");
    for(String str : coll){//变量Str代表被遍历到的集合元素
    	System.out.println(str);
    }

```

> 增强for循环和老式的for循环有什么区别？

> 遍历数组时，如果仅为遍历，可以使用增强for如果要对数组的元素进行操作,增强for循环不能操作索引

---

## 泛型

### 泛型的引入

> 在前面学习集合时，我们都知道集合中是可以存放任意对象的，只要把对象存储集合后，那么这时他们都会被提升成Object类型。当我们在取出每一个对象，并且进行相应的操作，这时必须采用类型转换

```
    public class GenericDemo {
	    public static void main(String[] args) {
    		List list = new ArrayList();
    		list.add("abc");
    		list.add("def");
    		list.add(5);//由于集合没有做任何限定，任何类型都可以给其中存放
    		Iterator it = list.iterator();
    		while(it.hasNext()){
    			//需要打印每个字符串的长度,就要把迭代出来的对象转成String类型
    			String str = (String) it.next();
    			// 求出每一个字符串的长度
    			System.out.println(str.length());
    		}
	    }
    }

```

> 程序在运行时发生了问题java.lang.ClassCastException

> 为什么会发生类型转换异常呢？我们来分析下:

> 由于集合中什么类型的元素都可以存储。导致取出时，如果出现强转就会引发运行时 ClassCastException。怎么来解决这个问题呢？使用集合时，必须明确集合中元素的类型。这种方式称为：泛型

---

### 泛型的定义与使用

> 我们在集合中会大量使用到泛型，这里来完整地学习泛型知识

> 泛型，用来灵活地将数据类型应用到不同的类、方法、接口当中。将数据类型作为参数进行传递

---

### 含有泛型的类

* 定义格式：修饰符 class 类名<代表泛型的变量> {  }
    * 例如，API中的ArrayList集合
    
    ```
    class ArrayList<E>{
        public boolean add(E e) { }
        public E get(int index){  }
    }
    ```

* 使用格式 : 创建对象时，确定泛型的类型
    * 例如，ArrayList<String> list = new ArrayList<String>();
    * 此时，变量E的值就是String类型
    
    ```
        class ArrayList<String>{ 
            public boolean add(String e){ }
    	    public String get(int index){  }
        }
    ```
    
    * 例如，ArrayList<Integer> list = new ArrayList<Integer
    * 此时，变量E的值就是Integer类型
    
    ```
        class ArrayList<Integer>{ 
            public boolean add(Integer e){ }
	        public Integer get(int index){  }
        }
    ```
    
### 含有泛型的方法

> 定义格式: 修饰符 <代表泛型的变量> 返回值类型 方法名(参数){  }

* 例如，API中的ArrayList集合中的方法

```
    public <T> T[] toArray(T[] a){  } 
    //该方法，用来把集合元素存储到指定数据类型的数组中，返回已存储集合元素的数组
```

> 使用格式 : 调用方法时，确定泛型的类型
* 例如

```
   public <String> String[] toArray(String[] a){  }
   public <Integer> Integer[] toArray(Integer[] a){  } 
```

### 含有泛型的接口

> 定义格式：修饰符 interface接口名<代表泛型的变量> {  }

* 例如，API中的Iterator迭代器接口

```
    public interface Iterator<E> {
    	public abstract E next();
    }
```

> 使用格式:


* 一. 例如
    
    ```
        public final class Scanner implements Iterator<String> {
              public String next(){  }
        }
        // 此时变量E就是String类型
    ```
    
* 二.始终不确定泛型的类型，直到创建对象时，确定泛型的类型
    
    ```
        ArrayList<String> list = new ArrayList<String>();
        Iterator<String> it = list.iterator();
        // 此时，变量E就是String类型
    ```

---

### 使用泛型的好处

* 将运行时期的ClassCastException,转移到了编译时期变成编译失败
* 避免了类型强转的麻烦

```
    public class GenericDemo {
    	public static void main(String[] args) {
    		List<String> list = new ArrayList<String>();
    		list.add("a");
    		//list.add(5);//当集合明确类型后，存放类型不一致就会编译报错
    		//集合已经明确具体存放的元素类型，那么在使用迭代器的时候，迭代器也同样会知道具体遍历元素类型
    		Iterator<String> it = list.iterator();
    		while(it.hasNext()){
            	String str = it.next();
                //当使用Iterator<String>控制元素类型后，就不需要强转了。获取到的元素直接就是String类型
        		System.out.println(str.length());
    		}
    	}
    }

```

---

### 泛型通配符

> 泛型是在限定数据类型，当在集合或者其他地方使用到泛型后，那么这时一旦明确泛型的数据类型，那么在使用的时候只能给其传递和数据类型匹配的类型，否则就会报错

> 代码演示

* 定义迭代集合元素的方法

```
    public static void printCollection(Collection<Person> list) {
    	Iterator<Person> it = list.iterator();
    	while (it.hasNext()) {
    		System.out.println(it.next());
    	}
    }
```

* 调用方法

```
    public static void main(String[] args){
         Collection<Student> list = new ArrayList<Student>();
         printCollection(list);
    }
```

> 上面调用方法语句属于语法错误，因为泛型限定不一致。方法要的是Collection<Person>类型，传入的是Collection<Student>，二者类型不匹配

> 上述定义的printCollection方法中，由于定义的是打印集合的功能，应该是可以打印任意集合中元素的。但定义方法时，根本无法确定具体集合中的元素类型是什么。为了解决这个“无法确定具体集合中的元素类型”问题，java中，为我们提供了泛型的通配符<?>

* 对上面的方法，进行修改后，实现了可迭代任意元素类型集合的方法

```
    public static void printCollection(Collection<?> list) {
    	Iterator<?> it = list.iterator();
    	while (it.hasNext()) {
    		System.out.println(it.next());
    	}
    }

```
---

* 总结
    * 当使用泛型类或者接口时，传递的数据中，泛型类型不确定，可以通过通配符<?>表示。但是一旦使用泛型的通配符后，只能使用Object类中的共性方法，集合中元素自身方法无法使用