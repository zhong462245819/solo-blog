title: flyway数据库管理工具
date: '2019-09-03 23:16:54'
updated: '2019-09-03 23:16:54'
tags: [工具]
permalink: /articles/2019/09/03/1567523814503.html
---
使用flyway的好处，能便捷的统一开发人员的数据库结构和数据
--- 
* **概念：** Flyway是独立于数据库的应用、管理并跟踪数据库变更的数据库版本管理工具。用通俗的话讲，Flyway可以像SVN管理不同人的代码那样，管理不同人的sql脚本，从而做到数据库同步。
* **支持的数据库类型：**  Oracle, SQL Server, SQL Azure, DB2, DB2 z/OS, MySQL (including Amazon RDS), MariaDB, Google Cloud SQL, PostgreSQL (including Amazon RDS and Heroku), Redshift, Vertica, H2, Hsql, Derby, SQLite, SAP HANA, solidDB, Sybase ASE and Phoenix。
* **sql脚本的命名规范：**   V+版本号(版本号的数字间以"."或"_"分隔开)+双下划线(用来分隔版本号和描述)+文件描述+后缀名，例如：V2017.9.30__Update.sql。
* **Flyway读取sql脚本的默认位置：** 项目的源文件夹下的db/migration目录。
* **指令：**  migrate、clean、info、validate、baseline、repair。
* **Flyway 的优势：** 
        1. 不仅支持sql 脚本，还支持Java 代码直接操作数据库（flyway-core-x.x.x.jar）；
        2. 有Maven 插件；
        3. 支持命令行
	4. 与Spring 框结合，很方便地实现应用启动时自动检查并升级数据库的功能。

* **Flyway命令行工具的使用：** 
       1. 解压下载flyway-commandlin 版本并解压到本地，结构图如下：
       2. 将sql脚本放在Flyway默认的db/migration目录下，如果放在其他位置需要修改conf/flyway.conf文件中的flyway.locations。
       3. 根据自己的情况修改conf/flyway.conf文件中的flyway.url、flyway.user、flyway.password。
       4. 在命令行执行migrate命令。
* **引入maven依赖坐标：** 
	``` 
        <!-- flyway -->
        <dependency>
            <groupId>org.flywaydb</groupId>
            <artifactId>flyway-core</artifactId>
            <version>4.2.0</version>
        </dependency>
	```
* **maven插件：** 
```
<plugin>
        <groupId>org.flywaydb</groupId>
        <artifactId>flyway-maven-plugin</artifactId>
        <configuration>
          <url>jdbc:mysql://${mysql.host}:${mysql.port}/creekson_dev?characterEncoding=utf8&useSSL=false</url>
          <user>creekson_dev</user>
          <password>Vb9icJbQk2daikAA</password>
        </configuration>
        <dependencies>
          <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>5.1.48</version>
          </dependency>
        </dependencies>
      </plugin>
```