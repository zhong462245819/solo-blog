title: mybatis应用(与spring整合)
date: '2019-09-01 22:45:37'
updated: '2019-09-01 22:45:37'
tags: [Note]
permalink: /articles/2019/09/01/1567349137117.html
---
#### 整合思路 
* 需要spring通过单例方式管理SqlSessionFactory。
* spring和mybatis整合生成代理对象，使用SqlSessionFactory创建SqlSession。（spring和mybatis整合自动完成）
* 持久层的mapper都需要由spring进行管理。
#### 整合环境 
* 创建一个新的java工程（接近实际开发的工程结构）
* jar包： 
    * mybatis3.2.7的jar包
    * spring3.2.0的jar包
    * mybatis和spring的整合包：早期ibatis和spring整合是由spring官方提供，mybatis和spring整合由mybatis提供。 

#### Mybatis逆向工程
* 什么是逆向工程 
    * mybaits需要程序员自己编写sql语句，mybatis官方提供逆向工程 可以针对单表自动生成mybatis执行所需要的代码（mapper.java,mapper.xml、po..）
    * 企业实际开发中，常用的逆向工程方式：由于数据库的表生成java代码。