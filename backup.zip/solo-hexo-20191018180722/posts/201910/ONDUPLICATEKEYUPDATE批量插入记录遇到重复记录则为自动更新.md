title: ON DUPLICATE KEY UPDATE批量插入记录，遇到重复记录则为自动更新
date: '2019-10-13 17:42:35'
updated: '2019-10-13 17:42:35'
tags: [mysql]
permalink: /articles/2019/10/13/1570959755359.html
---
*  使用 ON DUPLICATE KEY UPDATE 一条sql解决批量更新和主键重复问题(id为主键)
```
INSERT INTO mytable(id,pid,ele,anim) 
VALUES (?,?,?,?),(?,?,?,?),(?,?,?,?)
ON DUPLICATE KEY UPDATE pid=VALUES(pid),ele=VALUES(ele)
//pid=VALUES(pid),ele=VALUES(ele) 表示出现在values中某列的id字段值与表中已有id字段值重复时，会更新对应记录的这两个字段
 
//还可以指定其它值或进行运算：pid=pid+1，ele=ele-1
 
//因为这里未指定列 anim,所以遇到重复id的列，表中该列的 anim字段不会更新
 
//如果某列作为新记录被插入，则受影响行的值为1；如果表中原有的记录被更新，则受影响行的值为2
```
它不但对唯一主键有效，对复合主键同样有效，复合主键设置：
`ALTER TABLE mytable ADD(CONSTRAINT PRIMARY KEY(id,pid));`
不过ON DUPLICATE KEY UPDATE只是MySQL的特有语法，并不是SQL标准语法，不要乱用哦

转自：https://my.oschina.net/codespring/blog/411889
