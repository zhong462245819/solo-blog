title: git常用命令
date: '2019-09-03 23:15:30'
updated: '2019-09-03 23:18:08'
tags: [Git]
permalink: /articles/2019/09/03/1567523730273.html
---
1. `git branch` 查看本地分支 `git branch -a` 查看远程分支
2. `git remote update origin -p` 更新远程分支列表
