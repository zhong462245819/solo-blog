title: 06 - Java流程控制语句0
date: '2019-09-01 22:45:34'
updated: '2019-09-01 22:45:34'
tags: [Note]
permalink: /articles/2019/09/01/1567349134098.html
---
### 流程控制语句

```
    今日内容:
        
        if...
        if...else
        if ... else if ... else
        switch ... case
        for
        while
        do ... while
```

#### 分支结构if

> ​接下来要学习的if条件语句分为三种语法格式，每一种格式都有它自身的特点，下面我们分别进行介绍 

##### if语句

> ​	if语句是指如果满足某种条件，就进行某种处理。例如，小明妈妈跟小明说“如果你考试得了100分，星期天就带你去游乐场玩”。这句话可以通过下面的一段伪代码来描述 
>
> ```
> 如果小明考试得了100分
> 	妈妈星期天带小明去游乐场
> ```
>
> ​	在上面的伪代码中，“如果”相当于Java中的关键字if，“小明考试得了100分”是判断条件，需要用()括起来，“妈妈星期天带小明去游乐场”是执行语句，需要放在{}中。修改后的伪代码如下：
>
> ```
> if(小明考试得了100分){
>     妈妈星期天带小明去游乐场
> }
> ```
>
> ​	上面的例子就描述了if语句的用法，在Java中，if语句的具体语法格式如下：
>
> ```
> if(条件语句){ // 条件语句判断是一个布尔值，当值位true时，{ }里面的执行语句才会执行
>     执行语句；
> }
> ```
>
##### if语句的执行流程图:
>
> ![1528738167033](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/CE1589DC49A54149B65AA6977E1FE22B/28398)
>
> 上诉例子代码演示:
>
> ```
> public class Demo1{
>     public static void main(String[] args){
>         int xiaoMing = 100;
>         if(xiaoMing == 100){
>             System.out.println("妈妈星期天带小明去游乐场玩");
>         }
>     }
> }
> ```

##### if...else语句

> ​	if…else语句是指如果满足某种条件，就进行某种处理，否则就进行另一种处理。例如，要判断一个正整数的奇偶，如果该数字能被2整除则是一个偶数，否则该数字就是一个奇数。if…else语句具体语法格式如下 :
>
> ```
> if(条件语句){
>     执行语句1；
>     ......
> }else{
>     执行语句2;
>     ......
> }
> ```
>
> ​	上述代码中，判断条件是一个布尔值。当判断条件为true时，if后面{}中的执行语句1会执行。当判断条件为false时，else后面{}中的执行语句2会执行。
>
##### if…else语句的执行流程如下图所示 ：
>
> ![1528738200306](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/68D27DB5293842F290FF80D5F413E586/28400)
>
> 接下来通过一段代码，来实现判断奇偶数的程序
>
> ```
> public class Demo2{
>     public static void main(String[] args){
>         int num = 10;
>         if(num % 2 == 0){
>             System.out.println("num是一个偶数");
>         }else{
>             System.out.println("num是一个奇数");
>         }
>     }
> }
> ```

##### if ... else if ... else 语句

> ​	if…else if…else语句用于对多个条件进行判断，进行多种不同的处理。例如，对一个学生的考试成绩进行等级的划分，如果分数大于80分等级为优，否则，如果分数大于70分等级为良，否则，如果分数大于60分等级为中，否则，等级为差.
>
> ​	if…else if…else语句具体语法格式:
>
> ```
> if(判断条件1){
>     执行语句1；
> }else if(判断条件2){
>     执行语句2；
> }
> ......
> else if(判断语句n){
>     执行语句n;
> }else{
>     执行语句n+1;
> }
> ```
>
> ​	上述格式中，判断条件是一个布尔值。当判断条件1为true时，if后面{}中的执行语句1会执行。当判断条件1为false时，会继续执行判断条件2，如果为true则执行语句2，以此类推，如果所有的判断条件都为false，则意味着所有条件均未满足，else后面{}中的执行语句n+1会执行 
>
##### if…else if…else语句的执行流程如下图所示 ：
>
> ![1529031563518](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/E69D0A5B57EE49F89D7214D6B21D625E/28402)
>
> 接下来通过一段代码，来实现对学生考试成绩进行等级划分
>
> ```
> public class Demo3{
>     public static void main(String[] args){
>         int score = 75;//定义学生分数
>         if(score > 80){
>             System.out.println("优");
>         }else if(score > 70){
>             System.out.println("良");
>         }else if(score > 60){
>             System.out.println("刚刚好");
>         }else{
>             System.out.println("差");
>         }
>     }
> }
> ```

##### if的嵌套使用

> ```
> public class Demo4{
>     double height = 110;
>     double weight = 1110;
>     if(height >= 110){
>         System.out.println("你很优秀");
>         if(weight >= 1110){
>             System.out.println("陈独秀，请坐！");
>         }else{
>             System.out.println("你还是好好学java吧!");
>         }
>     }else{
>         System.out.println("你需要更加完美!");
>     }
> }
> ```

---

##### 选择结构 switch...case

> 简述switch的格式及流程?
>
> ```
> 表达式可以是: byte、short、int、char、String、枚举
> 		jdk 1.0 : byte,short,int,char
> 		jdk 1.5 : 枚举 enum
> 		jdk 1.7 : 字符串 String
> switch (表达式) {
> 	case 常量1 :
> 		要执行代码;
> 	break;
> 	case 常量2 :
> 		要执行代码;
> 	break;
> 		...
> 	default :
> 		要执行代码;
> 	break;
> }
> ```
>
> ```
> switch (1) {
> 	case 1 :
> 		System.out.println("礼拜一上班");
> 	break;
> 	case 2 :
> 		System.out.println("礼拜二出去游玩");
> 	break;
> 	case 3 :
> 		System.out.println("礼拜三搬砖");
> 	break;
> 	default :
> 		System.out.println("自嗨");
> 	break;
> }
> ```
>
> **switch 在什么情况下终止**:
> 		两种情况:
> 			遇到 break
> 			遇到 switch 的右大括号
>
> **注意:**
> 		case 后面 只可以跟常量
> 		case 后面 的常量值是不允许重复出现
> 		default 可以省略,也可以出现在 switch 语句的任意位置
> 		default 里的代码,一定是在所有的 case 都不匹配的情况下才会去执行!!!
>
> 练习：LOL段位

---

#### 循环结构

​	什么是循环?

​	例如: 

​	1.要做语文测试题了，班级里面有30个学生，老师要去打印30分卷子，这个时候打印机就循环执行了30次

​	2.数学里面 10 / 3 = 3.33333 ， 3无限循环

​	3.要求你们打印一千遍 "我爱编程，编程使我快乐!"

​		System.out.println("我爱编程，编程使我快乐!");

​		......

​		这条打印语句要写上一千遍，是不是会感觉很痛苦？

​	总结 : 当满足条件时，反复的执行某一段程序

##### while循环

> ​	while循环语句和选择结构if语句有些相似，都是根据条件判断来决定是否执行大括号内的执行语句。区别在于，while语句会反复地进行条件判断，只要条件成立，{}内的执行语句就会执行，直到条件不成立，while循环结束
>
> ​	while循环语句的语法结构如下 :
>
> ```
> while(循环条件){
>     执行语句；
>     ......
> }
> ```
>
> ​	在上面的语法结构中，{}中的执行语句被称作循环体，循环体是否执行取决于循环条件。当循环条件为true时，循环体就会执行。循环体执行完毕时会继续判断循环条件，如条件仍为true则会继续执行，直到循环条件为false时，整个循环过程才会结束.
>
> ​	while循环的执行流程如下图所示：
>
> ![1528738333249](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/F1E0DCD302454226A4F5821634C4DDC5/28404)
>
> 接下来通过一段代码来实现打印 1 ~ 10的自然数
>
> ```
> public class Demo5{
>     public static void main(String[] args){
>         int x = 1;//初始化变量x 赋值1
>         while(x <= 10){//循环条件
>         	//满足条件时
>             System.out.println("x = " + x);
>             x++;//x 进行自增
>         }
>     }
> }
> ```
>
> ​	在上述代码中，x初始值为1，在满足循环条件x <= 10的情况下，循环体会重复执行，打印x的值并让x进行自增。因此打印结果中x的值分别为1、2、3、4 ......。大家要注意的是，代码x++用于在每次循环时改变x的值，从而达到最终改变循环条件的目的。如果没有这行代码，整个循环会进入无限循环的状态，永远不会结束。

##### for循环

> ​	for循环语句是最常用的循环语句，一般用在循环次数已知的情况下。for循环语句的语法格式如下:
>
> ```
> for(初始化表达式;循环条件;操作表达式){
>     执行语句;
>     ......
> }
> ```
>
> ​	在上面的语法结构中，for关键字后面()中包括了三部分内容：初始化表达式、循环条件和操作表达式，它们之间用“;”分隔，{}中的执行语句为循环体 
>
> ​	接下来分别用①表示初始化表达式、②表示循环条件、③表示操作表达式、④表示循环体，通过序号来具体分析for循环的执行流程。具体如下:
>
> ```
> for(1;2;4){
>     3
> }
> 第一步，执行1
> 第二步，执行2，如果判断结果为true，执行第三步，如果判断结果为false，执行第五步
> 第三步，执行3
> 第四步，执行4，然后重复执行2 - 3  - 4 - 2 - 3 - 4
> 当 2 不满足时,退出循环
> ```
>
> ​	接下来通过一个案例对自然数1~4进行求和，如下所示 
>
> ```
> public class Demo6{
>     public static void main(String[] args){
>     	//定义一个sum变量求和
>         int sum = 0;
>         for(int i = 1;i <= 4;i++){
>             sum += i;
>         }
>         System.out.println("sum = " + sum);//10
>     }
> }
> ```
>
> ​	上述代码中，变量i的初始值为1，在判断条件i<=4为true的情况下，会执行循环体sum+=i，执行完毕后，会执行操作表达式i++，i的值变为2，然后继续进行条件判断，开始下一次循环，直到i=5时，条件i<=4为false，结束循环，执行for循环后面的代码，打印“sum=10” 
>
> ​	为了让初学者能熟悉整个for循环的执行过程，现将上述代码运行期间每次循环中变量sum和i的值通过表
>
> 罗列出来：
>
> | **循环次数** | **sum** | **i** |
> | ------------ | ------- | ----- |
> | 第一次       | 1       | 1     |
> | 第二次       | 3       | 2     |
> | 第三次       | 6       | 3     |
> | 第四次       | 10      | 4     |
>
> ​	练习:
>
> ​		1.求1加到 100的总和
>
> ​		2.求1加到100的奇数和
>
> ​		3.求1加到100的偶数和

##### do...while循环

> do…while循环语句和while循环语句功能类似，其语法结构如下 
>
> ```
> do{
> 	执行语句;
> 	......
> }while(循环条件);
> ```
>
> ​	在上面的语法结构中，关键字do后面{}中的执行语句是循环体。do…while循环语句将循环条件放在了循环体的后面。这也就意味着，循环体会无条件执行一次，然后再根据循环条件来决定是否继续执行 
>
> ​	do…while循环的执行流程如下图所示
>
> ![1528738420270](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/B3CAF62949144B95803D2A0346D5C9B0/28407)
>
> ​	接下来使用do…while循环语句来实现打印1~4之间的自然数
>
> ```
> public class Demo7{
> 	int x = 1;//初始化变量x,赋值为1
>     do{
>     	System.out.println("x = " + x);
> 	}while(x <= 4);
> }
> ```
>
> ​	总结 : do...while循环，先执行一次再去判断，无论如何都会执行一次
>
> ​	练习: 猜数字游戏.

##### 无限循环

> ​	最简单无限循环格式 ：
>
> ​		while(true){  }
>
> ​		或
>
> ​		for( ; ; ){ }
>
> ​		或
>
> ​		do{ }while(true);
>
> ​	无限循环存在的原因是并不知道循环多少次，而是根据某些条件，来控制循环

##### 嵌套循环

> ​	嵌套循环是指在一个循环语句的循环体中再定义一个循环语句的语法结构。while、do…while、for循环语句都可以进行嵌套，并且它们之间也可以互相嵌套，如最常见的在for循环中嵌套for循环，格式如下：
>
> ```
> for( 初始化表达式; 循环条件; 操作表达式){
>     ......
>     for( 初始化表达式; 循环条件; 操作表达式){
>         ......
>     }
>     ......
> }
> ```
>
> ​	接下来通过一个练习，来实现使用“*”打印直角三角形，如下所示
>
> ```
> public class Demo8{
>     public static void main(String[] args){
>         for( int i = 1; i <= 4;i++ ){ //外层循环
>             for(int j = 1;j<=i ;j++){ //内层循环
>                 System.out.print("*");//打印不换行，println这个是打印换行
>             }
>             System.out.println();
>         }
>     }
> }
> ```
>
> ​	结果如下图:
>
> ![1528738535488](https://note.youdao.com/yws/public/resource/905fe507d1dbcdd9d702e88e85feb62a/xmlnote/E6CFDA41ACC3432EB04D419298F93F62/28409)
>
> ​	在上述代码中定义了两层for循环，分别为外层循环和内层循环，外层循环用于控制打印的行数，内层循环用于打印“ * ”,每一行  “ * ”个数逐行增加，最后输出一个直角三角形。由于嵌套循环程序比较复杂，下面分步骤进行详细地讲解，具体如下:
>
> ​	第一步，在第3行代码定义了两个循环变量i和j，其中i为外层循环变量，j为内层循环变量 
>
> ​	第二步，在第4行代码将i初始化为1，条件i <= 4为true，首次进入外层循环的循环体
>
> ​	第三步，在第5行代码将j初始化为1，由于此时i的值为1，条件j <= i为true，首次进入内层循环的循环体，打印一个“ * ” 
>
> ​	第四步，执行第5行代码中内层循环的操作表达式j++，将j的值自增为2
>
> ​	第五步，执行第5行代码中的判断条件j<=i，判断结果为false，内层循环结束
>
> ​	第六步，执行第4行代码中外层循环的操作表达式i++，将i的值自增为2
>
> ​	第七步，执行第4行代码中的判断条件i<=4，判断结果为true，进入外层循环的循环体，继续执行内层循环
>
> ​	第八步，由于i的值为2，内层循环会执行两次，即在第2行打印两个“*”。在内层循环结束时会打印换行符 
>
> ​	第九步，以此类推，在第3行会打印3个“*”，逐行递增，直到i的值为5时，外层循环的判断条件i <= 4结果为false，外层循环结束，整个程序也就结束了

##### 跳转语句(break,continue)

> ​	跳转语句用于实现循环执行过程中程序流程的跳转，在Java中的跳转语句有break语句和continue语句。接下来分别进行详细地讲解 
>
#### break
>
> ​	在switch条件语句和循环语句中都可以使用break语句。当它出现在switch条件语句中时，作用是终止某个case并跳出switch结构。当它出现在循环语句中，作用是跳出循环语句，执行后面的代码 
>
> ​	接下来通过下面一段代码，实现将当变量x的值为3时，使用break语句跳出循环，代码如下所示：
>
> ```
> public class Demo9 {
> 	public static void main(String[] args) {
> 		int x = 1; // 定义变量x，初始值为1
> 		while (x <= 4) { // 循环条件
> 			System.out.println("x = " + x); // 条件成立，打印x的值
> 			if (x == 3) {
> 				break;
> 			}
> 			x++; // x进行自增
> 		}
> 	}
> }
> ```
>
#### 标记:
>
> ```
> public class BreakDemo{
> 	public static void main(String[] args) {
> 		int i, j; // 定义两个循环变量
> 		AAA: for (i = 1; i <= 9; i++) { // 外层循环
> 			for (j = 1; j <= i; j++) { // 内层循环
> 				if (i > 4) { // 判断i的值是否大于4
> 					break AAA; // 跳出外层循环
> 				}
> 				System.out.print("*"); // 打印*
> 			}
> 			System.out.print("\n"); // 换行
> 		}
> 	}
> }
> ```
>
#### continue语句
>
> ​	continue语句用在循环语句中，它的作用是终止本次循环，执行下一次循环
>
> ```
> public class ContinueDemo {
> 	public static void main(String[] args) {
> 		int sum = 0; // 定义变量sum，用于记住和
> 		for (int i = 1; i <= 100; i++) {
> 			if (i % 2 == 0) { // i是一个偶数，不累加
> 				continue; // 结束本次循环
> 			}
> 			sum += i; // 实现sum和i的累加
> 		}
> 		System.out.println("sum = " + sum);
> 	}
> }
> ```
>
>