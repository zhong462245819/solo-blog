title: 理解mybatis
date: '2019-09-01 22:45:37'
updated: '2019-09-01 22:45:37'
tags: [Note]
permalink: /articles/2019/09/01/1567349137503.html
---
##### 1、对原生态jdbc程序（单独使用jdbc开发）问题总结
-  数据库连接:使用时创建，不使用就关闭，对数据库进行频繁连接和开启，造成数据资源的浪费
    +  **解决**:使用数据库连接池管理数据库连接
- sql语句写在java代码中，需要修改sql语句时，需要对java代码重新编译，不易于维护
    - **解决**:将sql语句设置在xml配置文件中，即使sql变化，也无需重新编译  
- 向preparedStatement中设置参数，对占位符设置和设置参数值，写在java代码中不利于维护
    - **解决**：将sql语句及占位符，参数全部配置在xml文件中
- 从resutSet中遍历结果集数据时，存在硬编码，将获取表的字段进行硬编码，不利于系统维护
    - **解决**：将查询的结果集，自动映射成java对象

##### Mybatis框架原理
- 什么是Mybatis?
    - mybatis 是一个持久层的框架，是apache下的顶级项目。
    - mybatis 托管到Googlecode下，后来托管到GitHub下：[mybatis Github地址](https://github.com/mybatis/mybatis-3/releases)
    - mybatis让程序员可以将主要精力放在sql上，通过mybatis提供的映射方式，自由灵活生成(半自动化，大部分sql语句需要程序员编写)
    - mybatis可以将向preparedStatenment中的输入参数自动进行输入映射，将查询结果集灵活映射成java对象(输出映射)
- mybatis原理图
![image](https://img-blog.csdn.net/20180420191152719?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)