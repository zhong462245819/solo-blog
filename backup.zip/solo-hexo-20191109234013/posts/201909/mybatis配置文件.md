title: mybatis配置文件
date: '2019-09-01 22:45:27'
updated: '2019-09-01 22:45:27'
tags: [Note]
permalink: /articles/2019/09/01/1567349127666.html
---
## 配置资源文件(放在resources资源文件下)
    
#### log4j.properties：日志文件
    
    ```
    log4j.rootLogger=DEBUG,Console
    log4j.appender.Console=org.apache.log4j.ConsoleAppender
    log4j.appender.Console.layout=org.apache.log4j.PatternLayout
    log4j.appender.Console.layout.ConversionPattern=%d [%t] %-5p [%c] - %m%n
    log4j.logger.org.apache=INFO
    log4j.logger.org.apache.ibatis=ERROR
    ```
#### mysql.properties:JDBC连接配置文件
        * properties(属性)
            * 将数据库连接的参数单独配置在，db.properties中，只需要在SqlMapConfig.xml中加载db.properties的属性值。在SqlMapConfig.xml中就不需要对数据库连接参数硬编码。
            * 好处：方便对参数进行统一管理，其它xml可以引用该db.properties
            * 特性： MyBatis 将按照下面的顺序来加载属性：
                * 在 properties 元素体内定义的属性首先被读取。
                * 最后读取parameterType传递的属性，它会覆盖已读取的同名属性。
                * 不要在properties元素体内添加任何属性值，只将属性值定义在properties文件中
                * 在properties文件中定义属性名要有一定的特殊性，如XXXXX.XXXXX.XXXX 
    ```
    jdbc.driver=com.mysql.jdbc.Driver
    jdbc.url=jdbc:mysql://127.0.0.1:3306/demo?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false
    jdbc.username=root
    jdbc.password=123456
    ```
#### Mybatis-Config.xml：Mybatis配置文件
* properties(属性)
     1. 将数据库连接的参数单独配置在，db.properties中，只需要在SqlMapConfig.xml中加载db.properties的属性值。在SqlMapConfig.xml中就不需要对数据库连接参数硬编码。
     2. 好处：方便对参数进行统一管理，其它xml可以引用该db.properties
    3. 特性： MyBatis 将按照下面的顺序来加载属性：
        1. 在 properties 元素体内定义的属性首先被读取。
        2. 最后读取parameterType传递的属性，它会覆盖已读取的同名属性。
        3. 不要在properties元素体内添加任何属性值，只将属性值定义在properties文件中
                4. 在properties文件中定义属性名要有一定的特殊性，如XXXXX.XXXXX.XXXX
* settings（全局配置参数）
     1. mybatis框架在运行时可以调整一些运行参数。比如：开启二级缓存、开启延迟加载。。全局参数将会影响mybatis的运行行为。具体如下：   
 ![image](https://img-blog.csdn.net/20180422203142431?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
 ![image](https://img-blog.csdn.net/20180422203155118?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
 ![image](https://img-blog.csdn.net/20180422203206632?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)

 * typeAliases（类型别名）(重点) 
    * 单个定义
    ```
    <typeAliases>
        <typeAlias type="com.... " alias="别名"></typeAlias>
    </typeAliases>
    ```
    * 批量定义
    ```
    <typeAliases>
        <!--批量定义：mybatis自动扫描包中的类，别名就是类名-->
        <package type="com.... " alias="别名"></package>
    </typeAliases>
    ```
    * 默认支持的别名
        ![image](https://img-blog.csdn.net/20180422205223880?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
* typeHandlers（类型处理器） 
    * mybatis中通过typeHandlers完成jdbc类型和java类型的转换。通常情况下，mybatis提供的类型处理器满足日常需要，不需要自定义.
    * mybatis支持的类型处理器
    ![image](https://img-blog.csdn.net/2018042419301948?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
    ![image](https://img-blog.csdn.net/2018042419302869?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1NvbmdfSmlhbmdUYW8=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)
* objectFactory（对象工厂） 
    * 这个自行查看下载mybatis时附带的pdf文件，用的不多
* plugins（插件）
    * environments（环境集合属性对象） 
        * environment（环境子属性对象） 
        * transactionManager（事务管理）
        dataSource（数据源）
* mappers（映射器）
    * 通过resource 
    ```
    <mappers>
        <mapper resoutce=".xml文件"/> 
    </mappers>
    ```
    * 通过class 
    * 通过package(推荐使用)
    ```
    <mappers>
        <package name="com...."/>
    </mappers>
    ```
        ```
        <?xml version="1.0" encoding="UTF-8"?>
        <!DOCTYPE configuration
                PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
                "http://mybatis.org/dtd/mybatis-3-config.dtd">
        <configuration>
            <properties resource="mysql.properties"/>
            <settings>
                <!--全局性设置懒加载。如果设为‘false’，则所有相关联的都会被初始化加载,默认值为false-->
                <setting name="lazyLoadingEnabled" value="true"/>
                <!--当设置为‘true’的时候，懒加载的对象可能被任何懒属性全部加载。否则，每个属性都按需加载。默认值为true-->
                <setting name="aggressiveLazyLoading" value="false"/>
                <!--开启二级缓存-->
                <setting name="cacheEnabled" value="true"/>
            </settings>
            <!--别名-->
            <typeAliases>
                <!-- 其实就是将bean的替换成一个短的名字-->
                <typeAlias type="com.qf.pojo.User" alias="UserInfo"/>
            </typeAliases>
            <!--对事务的管理和连接池的配置-->
            <environments default="development">
                <environment id="development">
                    <transactionManager type="JDBC"></transactionManager>
                    <dataSource type="POOLED"><!--POOLED：使用Mybatis自带的数据库连接池来管理数据库连接-->
                        <property name="driver" value="${jdbc.driver}"/>
                        <property name="url" value="${jdbc.url}"/>
                        <property name="username" value="${jdbc.username}"/>
                        <property name="password" value="${jdbc.password}"/>
                    </dataSource>
                </environment>
            </environments>
            <!--mapping文件路径配置-->
            <mappers>
                <mapper resource="mapper/UserMapper.xml"/>
            </mappers>
        </configuration>
        ```