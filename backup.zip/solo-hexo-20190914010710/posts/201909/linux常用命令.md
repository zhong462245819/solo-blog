title: linux常用命令
date: '2019-09-03 23:14:19'
updated: '2019-09-03 23:14:19'
tags: [linux]
permalink: /articles/2019/09/03/1567523659000.html
---
1. cat 查看文本
2. vim编辑器
3. tail查看日志
