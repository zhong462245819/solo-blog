title: git常用命令
date: '2019-09-03 23:15:30'
updated: '2019-09-14 00:08:40'
tags: [Git]
permalink: /articles/2019/09/03/1567523730273.html
---
1. `git branch` 查看本地分支 `git branch -a` 查看远程分支
2. `git remote update origin -p` 更新远程分支列表
3. 基本命令
	* 初始化：创建一个git仓库，创建之后就会在当前目录生成一个.git的文件**
	* `git add filename`添加文件：把文件添加到缓冲区
	* `git add .`|`git add --all`*添加所有文件到缓冲区（从目前掌握的水平看，和后面加“.”的区别在于，加all可以添加被手动删除的文件，而加“.”不行）
	* `git rm filename`删除文件
	* `git commit -m "提交的说明"`commit可以一次提交缓冲区的所有文件
	* `git status`查看git库的状态，未提交的文件，分为两种，add过已经在缓冲区的，未add过的(红色未添加到缓冲区，绿色已添加)
	* `git diff filename ` **比较差异：** 如果文件修改了，还没有提交，就可以比较文件修改前后的差异
	* `git log ` **查看日志**
	* `git reset --hard HEAD^` **版本回退：** 回退到上一个版本（HEAD代表当前版本，有一个^代表上一个版本，以此类推）**
	* `git reset --hard xxxx` **版本回退：** 回退到指定版本(其中xxxx是想回退的指定版本号的前几位)
	* `git reflog` **查看命令历史：** 查看仓库的操作历史
	* `git log --graph` **查看分支合并图** 
	* `git tag 标签名 版本号` **新建标签** 
	* `git tag ` **查看所有标签**  
	* `git show 标签名 ` **查看标签的详细信息**  
	* `git push origin --tags ` **推送所有tag**  
	* `git push origin v1.0 ` **推送某个tag**  
	* `git remote add origin '远程仓库地址' ` **增加远程仓库**  
	* `git remote remove origin ` **移除远端仓库**  
	* `git push -u origin master` **推送本地仓库到远程仓库**  将本地仓库内容推送到远端仓库**(-u 表示第一次推送master分支的所有内容，后面再推送就不需要-u了)**  
	* `git pull` **更新远程仓库代码到本地**  tips:如果push的时候，本地和文件和远端文件有冲突，就要先pull、然后手动解决冲突，才能继续push


4. git分支管理
	* ` git branch`查看分支的情况，前面带*号的就是当前分支
	* `git branch 分支名`创建分支
	* `git checkout 分支名 `切换当前分支到指定分支
	* `git checkout  -b 分支名`创建分支并切换到创建的分支
	* `git merge 分支名`合并某分支的内容到当前分支
	* `git branch -d 分支名`删除分支

