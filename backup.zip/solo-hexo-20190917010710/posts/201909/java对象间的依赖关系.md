title: java对象间的依赖关系
date: '2019-09-01 22:45:23'
updated: '2019-09-01 22:45:23'
tags: [Note]
permalink: /articles/2019/09/01/1567349123291.html
---
* ==面向对象设计对象间关系：**依赖、关联、聚合和组合**，四种关系容易混淆。特别后三种，只是在语义上有所区别，所谓语义就是指上下文环境、特定情景等==。 
#### 依赖(Dependency)
* 依赖关系，是类与类之间的联接。依赖关系表示一个类依赖于另一个类的定义。使用关系。一般情况下，依赖关系在Java语言中体现为局域变量、方法的形参，或者对静态方法的调用。
```
package com.liuxd.relation;
/**
 * Created by Liuxd on 2018/9/11.
 */
public class DependencyTest {
    /**
     * 菜刀
     */
    static class Kinfe {
        public static void cutting(String name) {
        System.out.println("切" + name);
        }
    }
    /**
     *  厨师
     */
    class Chef {
        public void cutting(Kinfe kinfe, String vegetables) { kinfe.cutting(vegetables);
        }
    }
    public static void main(String[] args) {
        DependencyTest dependencyTest = new DependencyTest();
        Chef chef = dependencyTest.new Chef();
 
        Kinfe kinfe = new Kinfe();
 
        chef.cutting(kinfe,"carrot");
    }
}
```
#### 关联关系(Association）
* 关联关系，是类与类之间的联接，它使一个类知道另一个类的属性和方法。拥有关系。关联可以是双向的，也可以是单向的。在Java语言中，关联关系一般使用成员变量来实现。
```
package com.liuxd.relation;
/**
 * Created by Liuxd on 2018/9/11.
 */
public class AssociationTest {
    /**
     * 菜刀
     */
    static class Kinfe {
        public static void cutting(String name) {
        System.out.println("切" + name);
        }
    }
    /**
     *  厨师
     */
    class Chef {
        private Kinfe kinfe;
 
        public Chef(Kinfe kinfe){
            this.kinfe=kinfe;
        }
        public void cutting(Kinfe kinfe, String vegetables) {
        kinfe.cutting(vegetables);
        }
    }
    public static void main(String[] args) {
        AssociationTest dependencyTest = new AssociationTest();
        Kinfe kinfe = new Kinfe();
        Chef chef = dependencyTest.new Chef(kinfe);
        chef.cutting(kinfe,"carrot");
    }
}
```
#### 聚合(Aggregation)
* 聚合关系，是关联关系的一种，是强的关联关系。聚合是整体和个体之间的关系。例如，汽车类与引擎类、轮胎类，以及其它的零件类之间的关系便整体和个体的关系。与关联关系一样，聚合关系也是通过实例变量实现的。但是关联关系所涉及的两个类是处在同一层次上的，而在聚合关系中，两个类是处在不平等层次上的，一个代表整体，另一个代表部分。
```
// 母亲
class Mother {
    // 母亲可以有自己孩子, 但是不确定什么时候生
    private Children myChildren;
}
// 孩子
class Children {
}
```
#### 组合(Composition) 
* 组合关系，是关联关系的一种，是比聚合关系强的关系。它要求普通的聚合关系中代表整体的对象负责代表部分对象的生命周期，组合关系是不能共享的。代表整体的对象需要负责保持部分对象和存活，在一些情况下将负责代表部分的对象湮灭掉。代表整体的对象可以将代表部分的对象传递给另一个对象，由后者负责此对象的生命周期。换言之，代表部分的对象在每一个时刻只能与一个对象发生组合关系，由后者排他地负责生命周期。部分和整体的生命周期一样。
```
package com.liuxd.relation;
/**
 * Created by Liuxd on 2018/9/11.
 */
public class CompositionTest {
    /**
     * 菜刀
     */
    static class Kinfe {
        public static void cutting(String name) {
        System.out.println("切" + name);
        }
    }
    /**
     *  厨师
     */
    class Chef {
        Kinfe kinfe = new Kinfe();
        public void cutting(String vegetables) { kinfe.cutting(vegetables);
        }
    }
    public static void main(String[] args) {
        CompositionTest dependencyTest = new CompositionTest();
        Chef chef = dependencyTest.new Chef();
        chef.cutting("carrot");
    }
}
```
#### 总结
依赖和关联的区别：依赖是使用关系，关联是拥有关系；
聚合和组合的区别：聚合，是个体离开了整体，依然可以存在；组合，是个体和整体不可以分开，个体不能离开整体单独存在；
依赖，关联 和聚合，组合的区别:依赖，关联 : 类之间的关系是在同一层次上；聚合，组合: 类之间的关系表现为整体和部分.